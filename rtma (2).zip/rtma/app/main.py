"""
main.py

Application startup and window management.
"""

from ui.windows.SG_main_window import MainWindow
from ui.windows.signal_generator_desk import logger


def run_main_window():
    """
    Create and return the main application window.

    Returns
    -------
    MainWindow
        The main PyQt6 window with dock widgets.
    """
    logger.info("Getting main window...")
    return MainWindow()
