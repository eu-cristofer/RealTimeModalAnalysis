"""
app.py

Entry point to start the PyQt6 application.
"""

import sys
from PyQt6.QtWidgets import QApplication
from app.main import run_main_window


def main():
    """
    Initialize and run the main PyQt6 application loop.
    """
    app = QApplication(sys.argv)
    app.setApplicationName("RTMA - Real-Time Modal Analysis")

    main_window = run_main_window()
    main_window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()

